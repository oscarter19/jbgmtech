<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>JBGM Contigo en cada paso</title>

    <!-- Bootstrap core CSS -->
 <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
		
		<!-- Custom styles for this template -->
		<link href="<?php echo e(asset('css/modern-business.css')); ?>" rel="stylesheet">

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.html">JBGM Technology</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
							<a class="nav-link" href="/">Inicio</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="/about">Nuestra Empresa</a>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle active" href="/products" id="navbarDropdowProductos"data-toggle="dropdown"aria-hashpopup="true"    aria-expanded="false">
								Productos
							</a>
							<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
								<a class="dropdown-item" href="/quicksoft">Quick Suite</a>
								<a class="dropdown-item" href="/profoundlogic">Software Profound Logic</a>
								<a class="dropdown-item" href="revsoft">Software Rev-Soft</a>
							
							</div>
						</li>
						<li class="nav-item dropdown">
							<div>
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									Servicios
								</a>
								<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
									
									<a class="dropdown-item" href="/services">Soporte Técnico de Aplicaciones </a>
									<!--<a class="dropdown-item" href="portfolio-3-col.html">Outsourcing </a>
									-->
								</div>
							</div>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="/contact">Contacto</a>
						</li>
						
          </ul>
        </div>
      </div>
    </nav>

    <!-- Page Content -->
    <div class="container">

      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3">RevSoft
        <small>Rev View</small>
      </h1>

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="/">Inicio</a>
        </li>
        <li class="breadcrumb-item active">Rev View</li>
      </ol>

      <!-- Portfolio Item Row -->
      <div class="row">

        <div class="col-md-8">
          <img class="img-fluid" src="img/revsoft/view.png" alt="">
        </div>

        <div class="col-md-4">
          <h3 class="my-3">Componente de red de Rev View</h3>
          <p>Controle y administre TODAS las aplicaciones de RevSoft en cualquier plataforma de su empresa utilizando el marco de trabajo de red REV VIEW.</p>
          <h3 class="my-3">Siempre puedes monitorear y administrar</h3>
          <ul>
            <li>Trabajos programados críticos
           (REV SCHEDULER)</li>
            <li>Mensajes vitales
             (REV MENSAJE)</li>
            <li>Transferencias de datos
              (REV DATAFLOW)</li>
            <li>Entorno y disponibilidad
             (REV GUARDIAN)</li>
          </ul>
        </div>

      </div>
      <!-- /.row -->

      <!-- Related Projects Row -->
      <h3 class="my-4">Productos Relacionados</h3>

      <div class="row">

        <div class="col-md-3 col-sm-6 mb-4">
					<a href="/revSche"><img class="card-img-top" src="img/revsoftIcons/revScheduler.jpg" alt=""></a>
				</div>
				
				<div class="col-md-3 col-sm-6 mb-4">
					<a href="/revGuard"><img class="card-img-top" src="img/revSoftIcons/guardian.jpg" alt=""></a>
				</div>
				
				<div class="col-md-3 col-sm-6 mb-4">
					<a href="revmessage"><img class="card-img-top" src="img/revSoftIcons/message.jpg" alt=""></a>
				</div>
				
				<div class="col-md-3 col-sm-6 mb-4">
					<a href="revDataF"><img class="card-img-top" src="img/revSoftIcons/flow.jpg" alt=""></a>
				</div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Technology Solutions 2018</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
   <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
		<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>

  </body>

</html>
