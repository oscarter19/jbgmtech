
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>JBGM</title>
</head>
<body>
		<p><strong>Nombre: </strong><?php echo $name; ?></p>
		<p><strong>Telf: </strong><?php echo $telf; ?></p>
		<p><strong>Email: </strong><?php echo $email; ?></p>
		<p><strong>Mensaje: </strong><?php echo $msj; ?></p>
</body>
</html>		
		
		
		
	