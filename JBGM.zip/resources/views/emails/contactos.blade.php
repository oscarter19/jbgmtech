
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>JBGM</title>
</head>
<body>
		<p><strong>Nombre: </strong>{!!$name!!}</p>
		<p><strong>Telf: </strong>{!!$telf!!}</p>
		<p><strong>Email: </strong>{!!$email!!}</p>
		<p><strong>Mensaje: </strong>{!!$msj!!}</p>
</body>
</html>		
		
		
		
	